from PIL import Image, ImageDraw, ImageFont
from random import randint

img = Image.open('python.png')
draw = ImageDraw.Draw(img)
name = ImageFont.truetype('Gabriola.ttf', size=55)
text = input("Ismingizni kiriting >>")
draw.text((((600 - len(text) * 20) / 2), 280), text, font=name)
img.save(f'{randint(0,100)}.png')
img.show()